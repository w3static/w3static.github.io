<section id="cover" >
	<div class="wrapper flex" style="max-width: 100%;overflow: auto;background-image: url(lib/img/cvr.jpg);">
    	<div class="flexwrap">
    		<div class="hmm">
	    		<h1><span class="big flex"><span class="flexwrap">No</span></span><b class="flex"><span class="flexwrap">Limits<br/>Boundaries<br/>Excuses</span></b></h1>
	    		<br>
	    		<!-- <h2>Whatever You Need,<br/>You Are, it Takes!</h2> -->
    		</div>
	        <h3>Engineered Solutions That Work</h3>
	    </div>
    </div>
</section>
<section id="about">
	<div class="wrapper">
		<b>Rotex Alliance</b> specializing in surplus of Military and Commercial aircraft parts and instruments. Our strong work force has led us in being a leading Government supplier and a successful FAA Certified Repair Station. <b>Rotex Alliance</b> supplies excellent quality in spare parts and instruments for various military aircraft including C130, A-4, F-5, P-3, and also various Bell and Sikorsky Helicopters.
		<br>
		<br>
		<a href="about.html">Learn More</a>
	</div>
</section>